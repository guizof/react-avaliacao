import React from 'react';
import TextBig from './TextBig';
import Button from './Button';




export default function Banner(){
    return(
        <div className='banner container'>
            <div className="two-column content">
                <div className="inner-content">
                    <TextBig label="Festa Junina"/>
                    <p>‎</p>
                    <p>Durante as festas juninas no Brasil, são realizadas danças típicas, como as quadrilhas. Também há produção de inúmeras comidas à base de milho e amendoim, como canjica, pamonha, pé de moleque, além de bebidas como o quentão. Outra característica muito comum é a de se vestir de caipira de maneira caricata.</p>
                    <p>‎ </p>
                    <p>Horário: 14:00 até 18:00</p>
                    <p>Data: 26/06</p>
                    <p>Local: Sesi Senai São José, Distrito Industrial</p>
                    <p>‎</p>
                    <button className="inscri">Inscrição</button>
                </div>
            </div>
            <div className="two-column content">
                <img src="./festajunina.jpg" alt="Cachorro" srcset="" />
            </div>
        </div>
    )
}
