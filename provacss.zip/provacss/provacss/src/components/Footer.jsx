import React from 'react';
import Navbar from './Navbar';


export default function Footer(){
    return(
        <footer className='footer container'>
            <div className="logo">
                <p>Guilherme Morales Rigo 3-C</p>
            </div>
        </footer>
    )
}