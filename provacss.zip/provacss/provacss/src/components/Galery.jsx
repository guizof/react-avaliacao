import React from 'react';
import ItemImg from './ItemImg';
import TextBig from './TextBig';




export default function Galery(){
    return(
        <div className="one-column content">
            <TextBig label="‎" />
            <div className="imagem1">
                <ItemImg src="./docesjunina.jpg" label="Doces"/>
                <ItemImg src="./salgadosjunina.jpg" label="Salgados"/>
                <ItemImg src="./roupajunina.jpg" label="Roupas"/>
            </div>
            <div className="imagem2">
                <ItemImg src="./pescariajunina.webp" label="Pescaria"/>
                <ItemImg src="./quentaojunina.jpg" label="Quentão"/>
                <ItemImg src="./quadrilhajunina.webp" label="Quadrilha"/>
            </div>
        </div>
    )
}
