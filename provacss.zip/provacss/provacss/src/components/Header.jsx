import React from 'react';




export default function Header(){
    return(
        <header className='header container'>
            <div className="logo">
                <img src="./senai logo.png" alt="Logo" srcset="" />
            </div>
        </header>
    )
}
