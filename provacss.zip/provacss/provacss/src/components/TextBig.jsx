import React from 'react';

export default function TextBig({ label }) {
  return (
    <p className="text-big">
      {label}
    </p>
  );
}
